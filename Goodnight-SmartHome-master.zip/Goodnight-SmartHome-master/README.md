# Goodnight-SmartHome
SmartApp for SmartThings reads off windows or doors left open.

-->  This app requires that you also install the On/Off Button Tile Device Handler located here.


